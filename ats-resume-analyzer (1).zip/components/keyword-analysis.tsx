"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface KeywordAnalysisProps {
  keywords: {
    present: string[]
    missing: string[]
    density: number
  }
}

export function KeywordAnalysis({ keywords }: KeywordAnalysisProps) {
  const [isMounted, setIsMounted] = useState(false)

  // Check if component is mounted (client-side)
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Calculate keyword density color
  const getDensityColor = (density: number) => {
    if (density >= 0.7) return "text-green-600"
    if (density >= 0.5) return "text-yellow-600"
    return "text-red-600"
  }

  // If not mounted yet, return a placeholder
  if (!isMounted) {
    return (
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Keyword Analysis</h3>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Keyword Analysis</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Keywords are critical for passing ATS filters. Below is an analysis of the keywords in your resume.
        </p>

        <div className="mb-6">
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Keyword Density</span>
            <span className={getDensityColor(keywords.density)}>{Math.round(keywords.density * 100)}%</span>
          </div>
          <Progress value={keywords.density * 100} className="h-2" />
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Ideal keyword density is between 70-80%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-sm font-medium mb-3">Present Keywords</h4>
          <div className="flex flex-wrap gap-2">
            {keywords.present.map((keyword, index) => (
              <Badge
                key={index}
                variant="outline"
                className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800"
              >
                {keyword}
              </Badge>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium mb-3">Missing Keywords</h4>
          <div className="flex flex-wrap gap-2">
            {keywords.missing.map((keyword, index) => (
              <Badge
                key={index}
                variant="outline"
                className="bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300 dark:border-red-800"
              >
                {keyword}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg mt-6">
        <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">Keyword Optimization Tips:</h4>
        <ul className="text-sm text-blue-700 dark:text-blue-400 list-disc list-inside space-y-1">
          <li>Include industry-specific keywords from the job description</li>
          <li>Use both acronyms and full terms (e.g., "AI" and "Artificial Intelligence")</li>
          <li>Place important keywords in section headings</li>
          <li>Avoid keyword stuffing which can make your resume look spammy</li>
        </ul>
      </div>
    </div>
  )
}
