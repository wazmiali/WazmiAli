"use client"

import { useEffect, useState } from "react"
import { CheckCircle, AlertCircle, ArrowRight } from "lucide-react"

interface RecommendationsListProps {
  strengths: string[]
  weaknesses: string[]
  keywords: {
    present: string[]
    missing: string[]
    density: number
  }
  format: {
    issues: Array<{
      type: "warning" | "error" | "info"
      message: string
    }>
    compatibility: number
  }
}

export function RecommendationsList({ strengths, weaknesses, keywords, format }: RecommendationsListProps) {
  const [isMounted, setIsMounted] = useState(false)

  // Check if component is mounted (client-side)
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Generate recommendations based on the analysis
  const generateRecommendations = () => {
    const recommendations = []

    // Keyword recommendations
    if (keywords.missing.length > 0) {
      recommendations.push({
        title: "Add missing keywords",
        description: `Include these keywords in your resume: ${keywords.missing.slice(0, 3).join(", ")}${keywords.missing.length > 3 ? ", and others" : ""}`,
        priority: "high",
      })
    }

    if (keywords.density < 0.7) {
      recommendations.push({
        title: "Increase keyword density",
        description:
          "Your keyword density is below the recommended 70%. Try to incorporate more relevant industry terms.",
        priority: "medium",
      })
    }

    // Format recommendations
    format.issues.forEach((issue) => {
      if (issue.type === "warning" || issue.type === "error") {
        recommendations.push({
          title: "Fix format issue",
          description: issue.message,
          priority: issue.type === "error" ? "high" : "medium",
        })
      }
    })

    // General recommendations based on weaknesses
    weaknesses.forEach((weakness) => {
      recommendations.push({
        title: "Improve section",
        description: weakness,
        priority: "medium",
      })
    })

    // Add some general recommendations if we don't have enough
    if (recommendations.length < 3) {
      recommendations.push({
        title: "Use bullet points for achievements",
        description: "Convert paragraph-style descriptions to bullet points for better readability by ATS systems.",
        priority: "low",
      })

      recommendations.push({
        title: "Quantify your achievements",
        description: "Add numbers and percentages to highlight your accomplishments (e.g., 'Increased sales by 20%').",
        priority: "medium",
      })
    }

    // Sort by priority
    return recommendations.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 }
      return (
        priorityOrder[a.priority as keyof typeof priorityOrder] -
        priorityOrder[b.priority as keyof typeof priorityOrder]
      )
    })
  }

  // If not mounted yet, return a placeholder
  if (!isMounted) {
    return (
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Improvement Recommendations</h3>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
          <div className="space-y-3 mt-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const recommendations = generateRecommendations()

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-2">Improvement Recommendations</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Based on our analysis, here are actionable steps to improve your resume's ATS compatibility.
        </p>
      </div>

      <div className="space-y-4">
        {recommendations.map((recommendation, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border-l-4 ${
              recommendation.priority === "high"
                ? "border-red-500 bg-red-50 dark:bg-red-950"
                : recommendation.priority === "medium"
                  ? "border-yellow-500 bg-yellow-50 dark:bg-yellow-950"
                  : "border-blue-500 bg-blue-50 dark:bg-blue-950"
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="mt-0.5">
                {recommendation.priority === "high" ? (
                  <AlertCircle className="h-5 w-5 text-red-500" />
                ) : recommendation.priority === "medium" ? (
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                ) : (
                  <CheckCircle className="h-5 w-5 text-blue-500" />
                )}
              </div>
              <div>
                <h4 className="text-sm font-medium">{recommendation.title}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{recommendation.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-medium mb-4">What to Keep</h3>
        <div className="space-y-3">
          {strengths.map((strength, index) => (
            <div key={index} className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-950 rounded-md">
              <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
              <p className="text-sm">{strength}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-center mt-8">
        <button className="flex items-center gap-2 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium">
          View Sample ATS-Friendly Resume
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
