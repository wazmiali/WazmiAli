"use client"

import type React from "react"

import { useState, useRef } from "react"
import { UploadCloud } from "lucide-react"
import { validateFileType, validateFileSize } from "@/lib/security"

interface FileUploaderProps {
  onFileSelect: (file: File | null) => void
  accept?: string
  maxSize?: number
}

export function FileUploader({ onFileSelect, accept = ".pdf", maxSize = 5 * 1024 * 1024 }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [dragError, setDragError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const validateFile = (file: File): boolean => {
    setDragError(null)

    // Check file type
    const allowedTypes = ["application/pdf"]
    if (!validateFileType(file, allowedTypes)) {
      setDragError("Please upload a PDF file")
      return false
    }

    // Check file size
    if (!validateFileSize(file, maxSize)) {
      setDragError(`File size should not exceed ${maxSize / (1024 * 1024)}MB`)
      return false
    }

    return true
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    const files = e.dataTransfer.files
    if (files.length) {
      const file = files[0]
      if (validateFile(file)) {
        onFileSelect(file)
      } else {
        onFileSelect(null)
      }
    }
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const file = files[0]
      if (validateFile(file)) {
        onFileSelect(file)
      } else {
        onFileSelect(null)
      }
    }
  }

  const handleButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  return (
    <div>
      <div
        className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center min-h-[250px] cursor-pointer transition-colors ${
          isDragging
            ? "border-blue-500 bg-blue-50 dark:bg-blue-950"
            : dragError
              ? "border-red-300 bg-red-50 dark:bg-red-950"
              : "border-gray-300 dark:border-gray-700"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleButtonClick}
      >
        <input type="file" ref={fileInputRef} onChange={handleFileInputChange} accept={accept} className="hidden" />
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div
            className={`p-3 rounded-full ${dragError ? "bg-red-100 dark:bg-red-900" : "bg-blue-100 dark:bg-blue-900"}`}
          >
            <UploadCloud
              className={`h-8 w-8 ${dragError ? "text-red-600 dark:text-red-400" : "text-blue-600 dark:text-blue-400"}`}
            />
          </div>
          <div className="space-y-1">
            <p className="text-lg font-medium">
              {dragError ? "Error" : isDragging ? "Drop your file here" : "Drag & drop your resume"}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {dragError ? dragError : "or click to browse files"}
            </p>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">PDF up to 5MB</div>
        </div>
      </div>
    </div>
  )
}
