"use client"

import { useState } from "react"
import { AlertCircle, CheckCircle, Edit, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { escapeHtml } from "@/lib/security"

interface ResumeViewerProps {
  resumeText: string
  issues: Array<{
    type: "error" | "warning" | "suggestion"
    text: string
    startIndex: number
    endIndex: number
    suggestion?: string
  }>
}

export function ResumeViewer({ resumeText, issues }: ResumeViewerProps) {
  const [activeTab, setActiveTab] = useState("original")
  const [correctedText, setCorrectedText] = useState(resumeText)
  const [appliedCorrections, setAppliedCorrections] = useState<number[]>([])

  // Function to apply a correction
  const applyCorrection = (issue: any, index: number) => {
    if (!issue.suggestion || appliedCorrections.includes(index)) return

    const newText =
      correctedText.substring(0, issue.startIndex) + issue.suggestion + correctedText.substring(issue.endIndex)

    setCorrectedText(newText)
    setAppliedCorrections([...appliedCorrections, index])
  }

  // Function to download the corrected resume as a text file
  const downloadCorrectedResume = () => {
    const element = document.createElement("a")
    const file = new Blob([correctedText], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = "corrected_resume.txt"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  // Function to render text with highlighted issues
  const renderHighlightedText = (text: string, isOriginal = true) => {
    if (issues.length === 0) return <p className="whitespace-pre-wrap">{escapeHtml(text)}</p>

    // Sort issues by startIndex in descending order to avoid index shifting
    const sortedIssues = [...issues].sort((a, b) => b.startIndex - a.startIndex)

    // If we're viewing the corrected version, don't highlight fixed issues
    const relevantIssues = isOriginal
      ? sortedIssues
      : sortedIssues.filter((_, index) => !appliedCorrections.includes(index))

    // Start from the end of the text
    let lastIndex = text.length
    const elements = []

    for (const issue of relevantIssues) {
      // Add text after the current issue
      if (issue.endIndex < lastIndex) {
        elements.unshift(
          <span key={`text-${issue.endIndex}-${lastIndex}`}>
            {escapeHtml(text.substring(issue.endIndex, lastIndex))}
          </span>,
        )
      }

      // Add the highlighted issue
      const issueText = text.substring(issue.startIndex, issue.endIndex)
      const highlightClass =
        issue.type === "error"
          ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
          : issue.type === "warning"
            ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
            : "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"

      elements.unshift(
        <TooltipProvider key={`issue-${issue.startIndex}`}>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className={`px-0.5 rounded ${highlightClass}`}>{escapeHtml(issueText)}</span>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p>{escapeHtml(issue.text)}</p>
              {issue.suggestion && <p className="text-green-600 mt-1">Suggestion: {escapeHtml(issue.suggestion)}</p>}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>,
      )

      // Update lastIndex
      lastIndex = issue.startIndex
    }

    // Add text before the first issue
    if (lastIndex > 0) {
      elements.unshift(<span key="text-start">{escapeHtml(text.substring(0, lastIndex))}</span>)
    }

    return <div className="whitespace-pre-wrap">{elements}</div>
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <Tabs defaultValue="original" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="bg-gray-50 dark:bg-gray-800 p-4 border-b flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="original">Original Resume</TabsTrigger>
            <TabsTrigger value="corrected">Corrected Version</TabsTrigger>
          </TabsList>
          {activeTab === "corrected" && (
            <Button variant="outline" size="sm" onClick={downloadCorrectedResume} className="gap-2">
              <Download className="h-4 w-4" />
              Download
            </Button>
          )}
        </div>

        <TabsContent value="original" className="p-0">
          <div className="p-4 max-h-[500px] overflow-y-auto font-mono text-sm">{renderHighlightedText(resumeText)}</div>
          <div className="bg-gray-50 dark:bg-gray-800 p-4 border-t">
            <h4 className="text-sm font-medium mb-3">Issues Found ({issues.length})</h4>
            <div className="space-y-3">
              {issues.map((issue, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-3 p-3 rounded-md ${
                    issue.type === "error"
                      ? "bg-red-50 dark:bg-red-900/20"
                      : issue.type === "warning"
                        ? "bg-yellow-50 dark:bg-yellow-900/20"
                        : "bg-blue-50 dark:bg-blue-900/20"
                  }`}
                >
                  <div className="mt-0.5">
                    {issue.type === "error" ? (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    ) : issue.type === "warning" ? (
                      <AlertCircle className="h-4 w-4 text-yellow-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-blue-500" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{escapeHtml(issue.text)}</p>
                    {issue.suggestion && (
                      <div className="mt-2 flex items-center justify-between">
                        <p className="text-xs text-green-600 dark:text-green-400">
                          Suggestion: <span className="font-medium">{escapeHtml(issue.suggestion)}</span>
                        </p>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 gap-1"
                          onClick={() => applyCorrection(issue, index)}
                          disabled={appliedCorrections.includes(index)}
                        >
                          <Edit className="h-3 w-3" />
                          {appliedCorrections.includes(index) ? "Applied" : "Apply Fix"}
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="corrected" className="p-0">
          <div className="p-4 max-h-[500px] overflow-y-auto font-mono text-sm">
            {renderHighlightedText(correctedText, false)}
          </div>
          <div className="bg-gray-50 dark:bg-gray-800 p-4 border-t">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium">Corrections Applied</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {appliedCorrections.length} of {issues.filter((i) => i.suggestion).length} issues fixed
                </p>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-900 dark:text-green-300">
                <CheckCircle className="h-3 w-3 mr-1" />
                {Math.round((appliedCorrections.length / Math.max(1, issues.filter((i) => i.suggestion).length)) * 100)}
                % Improved
              </Badge>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
