"use client"

import { useState, useEffect } from "react"
import { AlertCircle, FileText, Loader2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface PDFParserProps {
  file: File
  onTextExtracted: (text: string, issues: any[]) => void
  onError: (error: string) => void
}

export function PDFParser({ file, onTextExtracted, onError }: PDFParserProps) {
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState("Initializing...")

  useEffect(() => {
    const parseFile = async () => {
      try {
        // In a real implementation, we would use pdf.js to extract text
        // For this demo, we'll simulate the parsing process
        setStatus("Loading PDF...")
        setProgress(10)
        await new Promise((resolve) => setTimeout(resolve, 500))

        setStatus("Extracting text...")
        setProgress(30)
        await new Promise((resolve) => setTimeout(resolve, 700))

        setStatus("Analyzing content...")
        setProgress(60)
        await new Promise((resolve) => setTimeout(resolve, 800))

        setStatus("Identifying issues...")
        setProgress(80)
        await new Promise((resolve) => setTimeout(resolve, 600))

        // Generate mock resume text and issues
        const mockResumeText = generateMockResumeText()
        const mockIssues = identifyIssues(mockResumeText)

        setStatus("Complete")
        setProgress(100)
        await new Promise((resolve) => setTimeout(resolve, 300))

        onTextExtracted(mockResumeText, mockIssues)
      } catch (error) {
        console.error("Error parsing PDF:", error)
        onError("Failed to parse PDF file. Please make sure it's a valid PDF document.")
      }
    }

    parseFile()
  }, [file, onTextExtracted, onError])

  // Generate a mock resume text with intentional issues
  const generateMockResumeText = () => {
    return `JOHN SMITH
123 Main Street, New York, NY 10001
john.smith@email.com | (555) 123-4567 | linkedin.com/in/johnsmith

PROFESSIONAL SUMMARY
Experienced project manager with over 8 years of experience in software development and team leadership. Skilled in agile methodologies and stakeholder management. Proven track record of delivering projects on time and under budget.

WORK EXPERIENCE

Senior Project Manager
ABC Technology Solutions, New York, NY
January 2018 - Present

• Led cross-functional teams of 10-15 members to deliver software projects with budgets exceeding $1.5M
• Implemented agile methodologies resulting in 30% faster delivery times and 25% reduction in defects
• Managed stakeholder expectations and communications across multiple departments
• Utilized MS Project, JIRA, and other project management tools to track progress and allocate resources efficiently

Project Manager
XYZ Software Inc., Boston, MA
March 2015 - December 2017

• Coordinated development of mobile applications for clients in finance and healthcare industries
• Managed project budgets ranging from $250K to $800K
• Conducted weekly status meetings and prepared reports for executive leadership
• Collaborated with sales team to develop project proposals and estimates

SKILLS

• Project Management: Agile, Waterfall, Scrum, budget planning
• Software: MS Project, JIRA, Confluence, Microsoft Office Suite
• Technical: Basic understanding of HTML, CSS, JavaScript
• Soft Skills: Leadership, Communication, Problem-solving, Negotiation

EDUCATION

Bachelor of Science in Business Administration
University of Massachusetts, Amherst
Graduated: May 2014
GPA: 3.7/4.0

CERTIFICATIONS

• Project Management Professional (PMP), 2016
• Certified ScrumMaster (CSM), 2017

REFERENCES

Available upon request`
  }

  // Identify issues in the resume text
  const identifyIssues = (text: string) => {
    const issues = [
      {
        type: "error",
        text: "Header contains special characters that may not parse correctly in ATS systems.",
        startIndex: 0,
        endIndex: 10,
        suggestion: "JOHN SMITH",
      },
      {
        type: "warning",
        text: "Phone number format may not be consistent with ATS parsing.",
        startIndex: text.indexOf("(555) 123-4567"),
        endIndex: text.indexOf("(555) 123-4567") + 14,
        suggestion: "555-123-4567",
      },
      {
        type: "error",
        text: "LinkedIn URL should be a hyperlink for better ATS compatibility.",
        startIndex: text.indexOf("linkedin.com"),
        endIndex: text.indexOf("linkedin.com") + 23,
        suggestion: "https://linkedin.com/in/johnsmith",
      },
      {
        type: "warning",
        text: "Bullet points using special characters may not parse correctly.",
        startIndex: text.indexOf("• Led"),
        endIndex: text.indexOf("• Led") + 1,
        suggestion: "- ",
      },
      {
        type: "suggestion",
        text: "Missing key industry keywords: Kanban, PMP, Risk Management.",
        startIndex: text.indexOf("SKILLS"),
        endIndex: text.indexOf("SKILLS") + 6,
        suggestion: "SKILLS & EXPERTISE",
      },
      {
        type: "error",
        text: "References section is unnecessary and takes up valuable space.",
        startIndex: text.indexOf("REFERENCES"),
        endIndex: text.indexOf("Available upon request") + 23,
        suggestion: "",
      },
      {
        type: "warning",
        text: "Education section should be moved higher in the resume for better visibility.",
        startIndex: text.indexOf("EDUCATION"),
        endIndex: text.indexOf("EDUCATION") + 9,
      },
      {
        type: "suggestion",
        text: "Add more quantifiable achievements to strengthen impact.",
        startIndex: text.indexOf("Managed stakeholder expectations"),
        endIndex: text.indexOf("Managed stakeholder expectations") + 45,
        suggestion:
          "Managed stakeholder expectations and communications across 5 departments, improving satisfaction by 40%",
      },
    ]

    return issues
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
          <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        </div>
        <div>
          <h3 className="font-medium">{file.name}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {(file.size / 1024 / 1024).toFixed(2)} MB • PDF Document
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <div className="flex items-center gap-2">
            {progress < 100 ? (
              <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-green-600" />
            )}
            <span>{status}</span>
          </div>
          <span>{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
    </div>
  )
}
