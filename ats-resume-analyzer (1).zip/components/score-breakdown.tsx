"use client"

import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"

interface ScoreBreakdownProps {
  sections: {
    keywords: number
    format: number
    sections: number
    contactInfo: number
    headerFooter: number
    fonts: number
    fileStructure: number
  }
}

export function ScoreBreakdown({ sections }: ScoreBreakdownProps) {
  const [isMounted, setIsMounted] = useState(false)

  // Check if component is mounted (client-side)
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Helper function to determine color based on score
  const getColorClass = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  // If not mounted yet, return a placeholder
  if (!isMounted) {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Score Breakdown</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="space-y-2">
              <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
              <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Score Breakdown</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Keyword Optimization</span>
            <span className={getColorClass(sections.keywords)}>{sections.keywords}%</span>
          </div>
          <Progress value={sections.keywords} className="h-2" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Format Compatibility</span>
            <span className={getColorClass(sections.format)}>{sections.format}%</span>
          </div>
          <Progress value={sections.format} className="h-2" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Section Completeness</span>
            <span className={getColorClass(sections.sections)}>{sections.sections}%</span>
          </div>
          <Progress value={sections.sections} className="h-2" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Contact Information</span>
            <span className={getColorClass(sections.contactInfo)}>{sections.contactInfo}%</span>
          </div>
          <Progress value={sections.contactInfo} className="h-2" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Header/Footer</span>
            <span className={getColorClass(sections.headerFooter)}>{sections.headerFooter}%</span>
          </div>
          <Progress value={sections.headerFooter} className="h-2" />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Font Compatibility</span>
            <span className={getColorClass(sections.fonts)}>{sections.fonts}%</span>
          </div>
          <Progress value={sections.fonts} className="h-2" />
        </div>
      </div>
    </div>
  )
}
