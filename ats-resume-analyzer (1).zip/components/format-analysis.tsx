"use client"

import { useEffect, useState } from "react"
import { AlertCircle, CheckCircle, Info } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface FormatAnalysisProps {
  format: {
    issues: Array<{
      type: "warning" | "error" | "info"
      message: string
    }>
    compatibility: number
  }
}

export function FormatAnalysis({ format }: FormatAnalysisProps) {
  const [isMounted, setIsMounted] = useState(false)

  // Check if component is mounted (client-side)
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Helper function to get icon based on issue type
  const getIssueIcon = (type: string) => {
    switch (type) {
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "info":
      default:
        return <Info className="h-4 w-4 text-blue-500" />
    }
  }

  // If not mounted yet, return a placeholder
  if (!isMounted) {
    return (
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Format Analysis</h3>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Format Analysis</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          The format of your resume affects how well ATS systems can parse your information.
        </p>

        <div className="mb-6">
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium">Format Compatibility</span>
            <span className="text-green-600">{Math.round(format.compatibility * 100)}%</span>
          </div>
          <Progress value={format.compatibility * 100} className="h-2" />
        </div>
      </div>

      <div>
        <h4 className="text-sm font-medium mb-3">Format Issues</h4>

        {format.issues.length === 0 ? (
          <div className="flex items-center gap-2 text-green-600 p-3 bg-green-50 dark:bg-green-950 rounded-md">
            <CheckCircle className="h-5 w-5" />
            <span>No format issues detected</span>
          </div>
        ) : (
          <div className="space-y-3">
            {format.issues.map((issue, index) => (
              <div
                key={index}
                className={`flex items-start gap-3 p-3 rounded-md ${
                  issue.type === "warning"
                    ? "bg-yellow-50 dark:bg-yellow-950"
                    : issue.type === "error"
                      ? "bg-red-50 dark:bg-red-950"
                      : "bg-blue-50 dark:bg-blue-950"
                }`}
              >
                <div className="mt-0.5">{getIssueIcon(issue.type)}</div>
                <div>
                  <p className="text-sm">{issue.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <h4 className="text-sm font-medium mb-3">ATS-Friendly Formats</h4>
          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Simple, clean layouts</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Standard section headings</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Bullet points for achievements</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Standard fonts (Arial, Calibri, Times)</span>
            </li>
          </ul>
        </div>

        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <h4 className="text-sm font-medium mb-3">ATS-Unfriendly Elements</h4>
          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <span>Tables and columns</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <span>Headers/footers with key info</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <span>Graphics and charts</span>
            </li>
            <li className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <span>Text boxes and WordArt</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
