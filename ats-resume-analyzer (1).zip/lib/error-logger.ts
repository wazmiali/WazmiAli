// Simple error logger that doesn't expose sensitive information
export function logError(error: unknown, context?: string): void {
  // In production, this would send to a logging service
  // without exposing sensitive details

  const errorMessage = error instanceof Error ? error.message : String(error)
  const sanitizedError = {
    message: errorMessage,
    context: context || "unknown",
    timestamp: new Date().toISOString(),
  }

  // Log sanitized error
  console.error("Application error:", sanitizedError)
}
