import Link from "next/link"
import { ArrowRight, CheckCircle } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <div className="space-y-12">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">About ATS Resume Analyzer</h1>
          <p className="text-gray-500 dark:text-gray-400 text-lg">
            Our mission is to help job seekers optimize their resumes for Applicant Tracking Systems (ATS) and increase
            their chances of landing interviews.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-bold mb-4">What is an ATS?</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              An Applicant Tracking System (ATS) is software used by employers to manage job applications. These systems
              scan, rank, and filter resumes before a human ever sees them.
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              Over 75% of companies use ATS software to screen candidates, which means your resume needs to be optimized
              for these systems to have the best chance of success.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">How Our Analyzer Works</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Our ATS Resume Analyzer uses advanced algorithms to evaluate your resume against key ATS criteria,
              including keyword optimization, format compatibility, and section completeness.
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              We provide a comprehensive score and actionable recommendations to help you improve your resume's
              performance with ATS systems.
            </p>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Our Scoring Methodology</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border">
              <h3 className="text-lg font-bold mb-3">Keyword Analysis (30%)</h3>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Industry-specific keyword presence</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Keyword density and distribution</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Job description keyword matching</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border">
              <h3 className="text-lg font-bold mb-3">Format Compatibility (40%)</h3>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>File structure and parsing ease</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Font and formatting compatibility</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Header/footer structure analysis</span>
                </li>
              </ul>
            </div>

            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border">
              <h3 className="text-lg font-bold mb-3">Content Quality (30%)</h3>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Section completeness</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Contact information visibility</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Achievement quantification</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 dark:bg-blue-950 p-8 rounded-xl">
          <h2 className="text-2xl font-bold mb-4">Ready to optimize your resume?</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Upload your resume now and get a comprehensive ATS compatibility analysis in minutes.
          </p>
          <Link href="/upload">
            <Button size="lg" className="gap-1.5">
              Analyze Your Resume <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold mb-2">Is my resume data secure?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Yes, we take data security seriously. Your resume is processed securely and is not stored on our servers
                unless you create an account. We never share your information with third parties.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-2">How accurate is the analysis?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Our analyzer is designed to simulate how major ATS systems process resumes. While no tool can predict
                with 100% accuracy how every ATS will handle your resume, our analysis is based on industry standards
                and best practices.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-2">Do I need to create an account?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                No, you can analyze your resume without creating an account. However, creating an account allows you to
                save your results, track improvements over time, and access additional features.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-2">Can I analyze multiple versions of my resume?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Yes, you can analyze as many versions of your resume as you like. This is especially useful if you're
                tailoring your resume for different job applications.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
