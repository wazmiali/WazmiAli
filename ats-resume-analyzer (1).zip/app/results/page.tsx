"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Download, FileText, Share, CheckCircle, AlertCircle, Info } from "lucide-react"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ResumeViewer } from "@/components/resume-viewer"

// Default mock data as fallback
const defaultResults = {
  overallScore: 78,
  sections: {
    keywords: 72,
    format: 85,
    sections: 90,
    contactInfo: 95,
    headerFooter: 65,
    fonts: 80,
    fileStructure: 75,
  },
  strengths: [
    "Strong experience section with quantifiable achievements",
    "Good use of industry-specific keywords",
    "Clear contact information",
  ],
  weaknesses: [
    "Header formatting may cause parsing issues",
    "Missing some key technical skills keywords",
    "Education section could be more detailed",
  ],
  keywords: {
    present: ["project management", "agile", "team leadership", "budget", "stakeholder"],
    missing: ["scrum", "kanban", "PMP", "risk management", "JIRA"],
    density: 0.68,
    industry: "Project Management",
    relevance: 0.75,
    competitiveScore: 65,
  },
  format: {
    issues: [
      { type: "warning", message: "Complex header may not parse correctly" },
      { type: "info", message: "Consider using bullet points for skills section" },
    ],
    compatibility: 0.85,
    fontAnalysis: {
      primary: "Arial (ATS-friendly)",
      secondary: "Calibri (ATS-friendly)",
      issues: ["Avoid using more than 2 font families"],
    },
    layoutIssues: ["Multi-column layout detected in skills section", "Tables used for formatting experience section"],
  },
  sectionAnalysis: {
    experience: {
      score: 88,
      strengths: ["Good use of action verbs", "Quantifiable achievements present"],
      weaknesses: ["Some bullet points exceed recommended length"],
    },
    education: {
      score: 85,
      strengths: ["Clear degree information", "Graduation dates included"],
      weaknesses: ["Consider adding relevant coursework"],
    },
    skills: {
      score: 72,
      strengths: ["Good mix of technical and soft skills"],
      weaknesses: ["Skills section could be more structured", "Missing some industry-specific keywords"],
    },
  },
  industryBenchmark: {
    overall: 65,
    keywords: 70,
    format: 68,
    sections: 62,
  },
  fileName: "example-resume.pdf",
  fileSize: 1024 * 1024 * 2, // 2MB
  uploadDate: new Date().toISOString(),
  resumeText: `JOHN SMITH
123 Main Street, New York, NY 10001
john.smith@email.com | (555) 123-4567 | linkedin.com/in/johnsmith

PROFESSIONAL SUMMARY
Experienced project manager with over 8 years of experience in software development and team leadership. Skilled in agile methodologies and stakeholder management. Proven track record of delivering projects on time and under budget.

WORK EXPERIENCE

Senior Project Manager
ABC Technology Solutions, New York, NY
January 2018 - Present

• Led cross-functional teams of 10-15 members to deliver software projects with budgets exceeding $1.5M
• Implemented agile methodologies resulting in 30% faster delivery times and 25% reduction in defects
• Managed stakeholder expectations and communications across multiple departments
• Utilized MS Project, JIRA, and other project management tools to track progress and allocate resources efficiently

Project Manager
XYZ Software Inc., Boston, MA
March 2015 - December 2017

• Coordinated development of mobile applications for clients in finance and healthcare industries
• Managed project budgets ranging from $250K to $800K
• Conducted weekly status meetings and prepared reports for executive leadership
• Collaborated with sales team to develop project proposals and estimates

SKILLS

• Project Management: Agile, Waterfall, Scrum, budget planning
• Software: MS Project, JIRA, Confluence, Microsoft Office Suite
• Technical: Basic understanding of HTML, CSS, JavaScript
• Soft Skills: Leadership, Communication, Problem-solving, Negotiation

EDUCATION

Bachelor of Science in Business Administration
University of Massachusetts, Amherst
Graduated: May 2014
GPA: 3.7/4.0

CERTIFICATIONS

• Project Management Professional (PMP), 2016
• Certified ScrumMaster (CSM), 2017

REFERENCES

Available upon request`,
  resumeIssues: [
    {
      type: "error",
      text: "Header contains special characters that may not parse correctly in ATS systems.",
      startIndex: 0,
      endIndex: 10,
      suggestion: "JOHN SMITH",
    },
    {
      type: "warning",
      text: "Phone number format may not be consistent with ATS parsing.",
      startIndex: 84,
      endIndex: 98,
      suggestion: "555-123-4567",
    },
    {
      type: "error",
      text: "LinkedIn URL should be a hyperlink for better ATS compatibility.",
      startIndex: 101,
      endIndex: 124,
      suggestion: "https://linkedin.com/in/johnsmith",
    },
    {
      type: "warning",
      text: "Bullet points using special characters may not parse correctly.",
      startIndex: 450,
      endIndex: 451,
      suggestion: "- ",
    },
    {
      type: "suggestion",
      text: "Missing key industry keywords: Kanban, PMP, Risk Management.",
      startIndex: 1300,
      endIndex: 1306,
      suggestion: "SKILLS & EXPERTISE",
    },
    {
      type: "error",
      text: "References section is unnecessary and takes up valuable space.",
      startIndex: 1800,
      endIndex: 1840,
      suggestion: "",
    },
    {
      type: "warning",
      text: "Education section should be moved higher in the resume for better visibility.",
      startIndex: 1600,
      endIndex: 1609,
    },
    {
      type: "suggestion",
      text: "Add more quantifiable achievements to strengthen impact.",
      startIndex: 700,
      endIndex: 745,
      suggestion:
        "Managed stakeholder expectations and communications across 5 departments, improving satisfaction by 40%",
    },
  ],
}

// Industry-specific keywords for different job types
const industryKeywords = {
  "Software Development": [
    "JavaScript",
    "React",
    "Node.js",
    "Python",
    "Java",
    "AWS",
    "Docker",
    "Kubernetes",
    "CI/CD",
    "Git",
    "REST API",
    "Microservices",
    "Agile",
    "Scrum",
    "Full Stack",
  ],
  "Data Science": [
    "Python",
    "R",
    "SQL",
    "Machine Learning",
    "Deep Learning",
    "TensorFlow",
    "PyTorch",
    "Data Visualization",
    "Statistical Analysis",
    "Big Data",
    "Hadoop",
    "Spark",
  ],
  "Project Management": [
    "PMP",
    "Agile",
    "Scrum",
    "Kanban",
    "JIRA",
    "Stakeholder Management",
    "Risk Management",
    "Budget Planning",
    "Resource Allocation",
    "Gantt Charts",
    "Milestone Tracking",
  ],
  Marketing: [
    "SEO",
    "SEM",
    "Content Marketing",
    "Social Media",
    "Google Analytics",
    "CRM",
    "Email Marketing",
    "A/B Testing",
    "Conversion Rate Optimization",
    "Brand Management",
  ],
  Finance: [
    "Financial Analysis",
    "Forecasting",
    "Budgeting",
    "Excel",
    "Financial Modeling",
    "Accounting",
    "CPA",
    "Risk Assessment",
    "Investment Analysis",
    "Portfolio Management",
  ],
}

export default function ResultsPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoaded, setIsLoaded] = useState(false)
  const [results, setResults] = useState(defaultResults)
  const [noAnalysisFound, setNoAnalysisFound] = useState(false)
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)
  const [selectedIndustry, setSelectedIndustry] = useState(results.keywords.industry || "Project Management")
  const [industryKeywordGap, setIndustryKeywordGap] = useState<string[]>([])
  const reportRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const { toast } = useToast()

  // Load results from localStorage when component mounts
  useEffect(() => {
    try {
      const savedResults = localStorage.getItem("resumeAnalysis")
      if (savedResults) {
        const parsedResults = JSON.parse(savedResults)
        setResults(parsedResults)
        setSelectedIndustry(parsedResults.keywords.industry || "Project Management")
      } else {
        // If no results found, we'll show a message but still display the default data
        setNoAnalysisFound(true)
        toast({
          title: "No analysis found",
          description: "We're showing sample data. Please upload a resume to get your own analysis.",
          variant: "default",
        })
      }
    } catch (error) {
      console.error("Error loading results:", error)
      toast({
        title: "Error loading results",
        description: "There was an error loading your analysis results.",
        variant: "destructive",
      })
    } finally {
      setIsLoaded(true)
    }
  }, [toast])

  // Calculate industry-specific keyword gaps
  useEffect(() => {
    if (selectedIndustry && industryKeywords[selectedIndustry as keyof typeof industryKeywords]) {
      const industrySpecificKeywords = industryKeywords[selectedIndustry as keyof typeof industryKeywords]
      const presentKeywords = results.keywords.present.map((kw) => kw.toLowerCase())

      // Find keywords that are in the industry list but not in the present keywords
      const missingIndustryKeywords = industrySpecificKeywords.filter(
        (kw) => !presentKeywords.some((pk) => pk.includes(kw.toLowerCase())),
      )

      setIndustryKeywordGap(missingIndustryKeywords.slice(0, 7)) // Limit to 7 keywords
    }
  }, [selectedIndustry, results.keywords.present])

  // If we're not on the client yet, show a simple loading state
  if (!isLoaded) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center min-h-[60vh]">
          <div className="h-16 w-16 border-4 border-t-blue-600 border-b-blue-600 border-l-transparent border-r-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    )
  }

  // Helper function to get color class based on score
  const getColorClass = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  // Function to generate and download PDF report
  const generatePDF = async () => {
    if (!reportRef.current) return

    setIsGeneratingPDF(true)
    toast({
      title: "Generating report",
      description: "Please wait while we generate your PDF report...",
    })

    try {
      const reportElement = reportRef.current
      const canvas = await html2canvas(reportElement, {
        scale: 2,
        logging: false,
        useCORS: true,
        allowTaint: true,
      })

      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      })

      const imgWidth = 210
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight)

      // If the report is longer than one page, add more pages
      if (imgHeight > 297) {
        let heightLeft = imgHeight - 297
        let position = -297

        while (heightLeft > 0) {
          position = position - 297
          pdf.addPage()
          pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
          heightLeft -= 297
        }
      }

      // Download the PDF
      pdf.save(`ATS_Resume_Analysis_${new Date().toISOString().split("T")[0]}.pdf`)

      toast({
        title: "Report downloaded",
        description: "Your ATS analysis report has been downloaded successfully.",
      })
    } catch (error) {
      console.error("Error generating PDF:", error)
      toast({
        title: "Error generating report",
        description: "There was an error generating your PDF report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingPDF(false)
    }
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <Link
          href="/"
          className="flex items-center text-sm text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>
      </div>

      {noAnalysisFound && (
        <div className="mb-6 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300 p-4 rounded-md flex items-center justify-between">
          <div>
            <p className="font-medium">No resume analysis found</p>
            <p className="text-sm mt-1">
              We're showing sample data. Upload your resume to get a personalized analysis.
            </p>
          </div>
          <Button size="sm" onClick={() => router.push("/upload")}>
            Upload Resume
          </Button>
        </div>
      )}

      <div className="space-y-6" ref={reportRef}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">ATS Analysis Results</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">
              Comprehensive analysis of your resume's ATS compatibility
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2" onClick={generatePDF} disabled={isGeneratingPDF}>
              {isGeneratingPDF ? (
                <>
                  <div className="h-4 w-4 border-2 border-t-transparent border-blue-600 rounded-full animate-spin"></div>
                  Generating...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  Download Report
                </>
              )}
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Share className="h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Overall ATS Score</CardTitle>
              <CardDescription>How well your resume performs with ATS systems</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center pt-2">
              <div className="relative flex items-center justify-center w-[180px] h-[180px]">
                <svg width="180" height="180" viewBox="0 0 180 180" className="transform -rotate-90">
                  <circle
                    cx="90"
                    cy="90"
                    r="80"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="16"
                    className="text-gray-200 dark:text-gray-700"
                  />
                  <circle
                    cx="90"
                    cy="90"
                    r="80"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="16"
                    strokeDasharray="502.4"
                    strokeDashoffset={502.4 - (results.overallScore / 100) * 502.4}
                    strokeLinecap="round"
                    className={`${
                      results.overallScore >= 80
                        ? "text-green-500"
                        : results.overallScore >= 60
                          ? "text-yellow-500"
                          : "text-red-500"
                    }`}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span
                    className={`text-3xl font-bold ${
                      results.overallScore >= 80
                        ? "text-green-500"
                        : results.overallScore >= 60
                          ? "text-yellow-500"
                          : "text-red-500"
                    }`}
                  >
                    {Math.round(results.overallScore)}
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">ATS Score</span>
                </div>
              </div>

              <div className="mt-6 w-full space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Recruiter Visibility</span>
                    <span>{Math.round(results.overallScore * 0.9)}%</span>
                  </div>
                  <Progress value={results.overallScore * 0.9} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Industry Benchmark</span>
                    <span className={getColorClass(results.industryBenchmark.overall)}>
                      {results.industryBenchmark.overall}%
                    </span>
                  </div>
                  <div className="relative pt-1">
                    <div className="flex mb-2 items-center justify-between">
                      <div>
                        <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                          Your score: {results.overallScore}%
                        </span>
                      </div>
                      <div>
                        <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-gray-600 bg-gray-200">
                          Industry avg: {results.industryBenchmark.overall}%
                        </span>
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                      <div
                        style={{ width: `${results.industryBenchmark.overall}%` }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-gray-500"
                      ></div>
                      <div
                        style={{ width: `${Math.max(0, results.overallScore - results.industryBenchmark.overall)}%` }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium text-sm mb-2">Resume Snapshot</h4>
                  <div className="flex items-center gap-3 text-sm">
                    <FileText className="h-4 w-4 text-gray-500" />
                    <span className="text-gray-600 dark:text-gray-400">{results.fileName || "resume.pdf"}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Pages</p>
                      <p className="font-medium">2</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Words</p>
                      <p className="font-medium">543</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Analyzed</p>
                      <p className="font-medium">
                        {results.uploadDate
                          ? new Date(results.uploadDate).toLocaleDateString()
                          : new Date().toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Format</p>
                      <p className="font-medium">PDF</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-6 w-full">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="keywords">Keywords</TabsTrigger>
                  <TabsTrigger value="format">Format</TabsTrigger>
                  <TabsTrigger value="sections">Sections</TabsTrigger>
                  <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                  <TabsTrigger value="resume">Resume Text</TabsTrigger>
                </TabsList>
                <TabsContent value="overview" className="mt-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Score Breakdown</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Keyword Optimization</span>
                          <span className={getColorClass(results.sections.keywords)}>{results.sections.keywords}%</span>
                        </div>
                        <Progress value={results.sections.keywords} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Format Compatibility</span>
                          <span className={getColorClass(results.sections.format)}>{results.sections.format}%</span>
                        </div>
                        <Progress value={results.sections.format} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Section Completeness</span>
                          <span className={getColorClass(results.sections.sections)}>{results.sections.sections}%</span>
                        </div>
                        <Progress value={results.sections.sections} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Contact Information</span>
                          <span className={getColorClass(results.sections.contactInfo)}>
                            {results.sections.contactInfo}%
                          </span>
                        </div>
                        <Progress value={results.sections.contactInfo} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Header/Footer</span>
                          <span className={getColorClass(results.sections.headerFooter)}>
                            {results.sections.headerFooter}%
                          </span>
                        </div>
                        <Progress value={results.sections.headerFooter} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Font Compatibility</span>
                          <span className={getColorClass(results.sections.fonts)}>{results.sections.fonts}%</span>
                        </div>
                        <Progress value={results.sections.fonts} className="h-2" />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Strengths</h3>
                      <ul className="space-y-2">
                        {results.strengths.map((strength, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5">
                              ✓
                            </span>
                            <span>{strength}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-lg font-medium mb-2">Areas to Improve</h3>
                      <ul className="space-y-2">
                        {results.weaknesses.map((weakness, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="flex-shrink-0 h-5 w-5 rounded-full bg-red-100 text-red-600 flex items-center justify-center mt-0.5">
                              !
                            </span>
                            <span>{weakness}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="keywords" className="mt-4">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium mb-4">Keyword Analysis</h3>
                        <div className="w-48">
                          <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select Industry" />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.keys(industryKeywords).map((industry) => (
                                <SelectItem key={industry} value={industry}>
                                  {industry}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        Keywords are critical for passing ATS filters. Below is an analysis of the keywords in your
                        resume.
                      </p>
                      <div className="mb-6">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Keyword Density</span>
                          <span className={getColorClass(results.keywords.density * 100)}>
                            {Math.round(results.keywords.density * 100)}%
                          </span>
                        </div>
                        <Progress value={results.keywords.density * 100} className="h-2" />
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          Ideal keyword density is between 70-80%
                        </p>
                      </div>

                      <div className="mb-6">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Industry Relevance</span>
                          <span className={getColorClass(results.keywords.relevance * 100)}>
                            {Math.round(results.keywords.relevance * 100)}%
                          </span>
                        </div>
                        <Progress value={results.keywords.relevance * 100} className="h-2" />
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          How well your keywords match the selected industry
                        </p>
                      </div>

                      <div className="mb-6">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Competitive Ranking</span>
                          <span className={getColorClass(results.keywords.competitiveScore)}>
                            {results.keywords.competitiveScore}%
                          </span>
                        </div>
                        <Progress value={results.keywords.competitiveScore} className="h-2" />
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          How your keywords compare to other candidates in {selectedIndustry}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium mb-3">Present Keywords</h4>
                        <div className="flex flex-wrap gap-2">
                          {results.keywords.present.map((keyword, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-xs dark:bg-green-950 dark:text-green-300 dark:border-green-800"
                            >
                              {keyword}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-3">Missing Keywords</h4>
                        <div className="flex flex-wrap gap-2">
                          {results.keywords.missing.map((keyword, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-red-50 text-red-700 border border-red-200 rounded-full text-xs dark:bg-red-950 dark:text-red-300 dark:border-red-800"
                            >
                              {keyword}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                      <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                        Industry-Specific Keywords for {selectedIndustry}
                      </h4>
                      <p className="text-sm text-blue-700 dark:text-blue-400 mb-3">
                        Consider adding these industry-specific keywords to your resume:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {industryKeywordGap.map((keyword, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-blue-100 text-blue-700 border border-blue-200 rounded-full text-xs dark:bg-blue-900 dark:text-blue-300 dark:border-blue-800"
                          >
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="format" className="mt-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Format Analysis</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        The format of your resume affects how well ATS systems can parse your information.
                      </p>
                      <div className="mb-6">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">Format Compatibility</span>
                          <span className="text-green-600">{Math.round(results.format.compatibility * 100)}%</span>
                        </div>
                        <Progress value={results.format.compatibility * 100} className="h-2" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium mb-3">Font Analysis</h4>
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="mb-3">
                            <p className="text-sm font-medium">Primary Font</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {results.format.fontAnalysis.primary}
                            </p>
                          </div>
                          <div className="mb-3">
                            <p className="text-sm font-medium">Secondary Font</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {results.format.fontAnalysis.secondary}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-medium">Font Issues</p>
                            <ul className="mt-1 text-sm text-gray-600 dark:text-gray-400 list-disc list-inside">
                              {results.format.fontAnalysis.issues.map((issue, index) => (
                                <li key={index}>{issue}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-3">Layout Issues</h4>
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                            {results.format.layoutIssues.map((issue, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <AlertCircle className="h-4 w-4 text-yellow-500 mt-0.5" />
                                <span>{issue}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-3">Format Issues</h4>
                      {results.format.issues.length === 0 ? (
                        <div className="flex items-center gap-2 text-green-600 p-3 bg-green-50 dark:bg-green-950 rounded-md">
                          <span>No format issues detected</span>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {results.format.issues.map((issue, index) => (
                            <div
                              key={index}
                              className={`flex items-start gap-3 p-3 rounded-md ${
                                issue.type === "warning"
                                  ? "bg-yellow-50 dark:bg-yellow-950"
                                  : issue.type === "error"
                                    ? "bg-red-50 dark:bg-red-950"
                                    : "bg-blue-50 dark:bg-blue-950"
                              }`}
                            >
                              <div className="mt-0.5">
                                {issue.type === "warning" ? (
                                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                                ) : issue.type === "error" ? (
                                  <AlertCircle className="h-4 w-4 text-red-500" />
                                ) : (
                                  <Info className="h-4 w-4 text-blue-500" />
                                )}
                              </div>
                              <div>
                                <p className="text-sm">{issue.message}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <h4 className="text-sm font-medium mb-3">ATS-Friendly Formats</h4>
                        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span>Simple, clean layouts</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span>Standard section headings</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span>Bullet points for achievements</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span>Standard fonts (Arial, Calibri, Times)</span>
                          </li>
                        </ul>
                      </div>

                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <h4 className="text-sm font-medium mb-3">ATS-Unfriendly Elements</h4>
                        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                          <li className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-red-500" />
                            <span>Tables and columns</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-red-500" />
                            <span>Headers/footers with key info</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-red-500" />
                            <span>Graphics and charts</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-red-500" />
                            <span>Text boxes and WordArt</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="sections" className="mt-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Section-by-Section Analysis</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        Detailed analysis of each section in your resume.
                      </p>
                    </div>

                    <div className="space-y-6">
                      {/* Experience Section Analysis */}
                      <div className="border rounded-lg overflow-hidden">
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 border-b">
                          <div className="flex justify-between items-center">
                            <h4 className="font-medium">Experience Section</h4>
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                results.sectionAnalysis.experience.score >= 80
                                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                  : results.sectionAnalysis.experience.score >= 60
                                    ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                              }`}
                            >
                              Score: {results.sectionAnalysis.experience.score}%
                            </span>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="mb-4">
                            <h5 className="text-sm font-medium mb-2 text-green-600 dark:text-green-400">Strengths</h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.experience.strengths.map((strength, index) => (
                                <li key={index}>{strength}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="text-sm font-medium mb-2 text-red-600 dark:text-red-400">
                              Areas to Improve
                            </h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.experience.weaknesses.map((weakness, index) => (
                                <li key={index}>{weakness}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      {/* Education Section Analysis */}
                      <div className="border rounded-lg overflow-hidden">
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 border-b">
                          <div className="flex justify-between items-center">
                            <h4 className="font-medium">Education Section</h4>
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                results.sectionAnalysis.education.score >= 80
                                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                  : results.sectionAnalysis.education.score >= 60
                                    ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                              }`}
                            >
                              Score: {results.sectionAnalysis.education.score}%
                            </span>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="mb-4">
                            <h5 className="text-sm font-medium mb-2 text-green-600 dark:text-green-400">Strengths</h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.education.strengths.map((strength, index) => (
                                <li key={index}>{strength}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="text-sm font-medium mb-2 text-red-600 dark:text-red-400">
                              Areas to Improve
                            </h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.education.weaknesses.map((weakness, index) => (
                                <li key={index}>{weakness}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      {/* Skills Section Analysis */}
                      <div className="border rounded-lg overflow-hidden">
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 border-b">
                          <div className="flex justify-between items-center">
                            <h4 className="font-medium">Skills Section</h4>
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                results.sectionAnalysis.skills.score >= 80
                                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                  : results.sectionAnalysis.skills.score >= 60
                                    ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                              }`}
                            >
                              Score: {results.sectionAnalysis.skills.score}%
                            </span>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="mb-4">
                            <h5 className="text-sm font-medium mb-2 text-green-600 dark:text-green-400">Strengths</h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.skills.strengths.map((strength, index) => (
                                <li key={index}>{strength}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="text-sm font-medium mb-2 text-red-600 dark:text-red-400">
                              Areas to Improve
                            </h5>
                            <ul className="text-sm space-y-1 list-disc list-inside">
                              {results.sectionAnalysis.skills.weaknesses.map((weakness, index) => (
                                <li key={index}>{weakness}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                      <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                        Section Order Recommendation
                      </h4>
                      <p className="text-sm text-blue-700 dark:text-blue-400 mb-3">
                        For optimal ATS performance, we recommend the following section order:
                      </p>
                      <ol className="text-sm text-blue-700 dark:text-blue-400 list-decimal list-inside space-y-1">
                        <li>Contact Information (at the top)</li>
                        <li>Professional Summary or Objective</li>
                        <li>Skills (especially for technical roles)</li>
                        <li>Professional Experience</li>
                        <li>Education</li>
                        <li>Certifications/Additional Training</li>
                        <li>Additional Sections (Awards, Publications, etc.)</li>
                      </ol>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="recommendations" className="mt-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Improvement Recommendations</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Based on our analysis, here are actionable steps to improve your resume's ATS compatibility.
                      </p>
                    </div>
                    <div className="space-y-4">
                      {results.weaknesses.map((weakness, index) => (
                        <div
                          key={index}
                          className="p-4 rounded-lg border-l-4 border-yellow-500 bg-yellow-50 dark:bg-yellow-950"
                        >
                          <div className="flex items-start gap-3">
                            <div>
                              <h4 className="text-sm font-medium">Improve your resume</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{weakness}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                      {results.keywords.missing.length > 0 && (
                        <div className="p-4 rounded-lg border-l-4 border-red-500 bg-red-50 dark:bg-red-950">
                          <div className="flex items-start gap-3">
                            <div>
                              <h4 className="text-sm font-medium">Add missing keywords</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                Include these keywords in your resume: {results.keywords.missing.slice(0, 3).join(", ")}
                                {results.keywords.missing.length > 3 ? ", and others" : ""}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {industryKeywordGap.length > 0 && (
                        <div className="p-4 rounded-lg border-l-4 border-blue-500 bg-blue-50 dark:bg-blue-950">
                          <div className="flex items-start gap-3">
                            <div>
                              <h4 className="text-sm font-medium">Add industry-specific keywords</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                To better target {selectedIndustry} roles, include these keywords:{" "}
                                {industryKeywordGap.slice(0, 5).join(", ")}
                                {industryKeywordGap.length > 5 ? ", and others" : ""}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {results.format.layoutIssues.length > 0 && (
                        <div className="p-4 rounded-lg border-l-4 border-orange-500 bg-orange-50 dark:bg-orange-950">
                          <div className="flex items-start gap-3">
                            <div>
                              <h4 className="text-sm font-medium">Fix formatting issues</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                Your resume has formatting that may confuse ATS systems:
                              </p>
                              <ul className="text-sm text-gray-600 dark:text-gray-400 mt-2 list-disc list-inside">
                                {results.format.layoutIssues.map((issue, index) => (
                                  <li key={index}>{issue}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mt-8">
                      <h3 className="text-lg font-medium mb-4">What to Keep</h3>
                      <div className="space-y-3">
                        {results.strengths.map((strength, index) => (
                          <div
                            key={index}
                            className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-950 rounded-md"
                          >
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                            <p className="text-sm">{strength}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg mt-6">
                      <h4 className="text-sm font-medium mb-3">Next Steps</h4>
                      <ol className="text-sm text-gray-600 dark:text-gray-400 list-decimal list-inside space-y-2">
                        <li>Download your detailed report for reference</li>
                        <li>Make the recommended changes to your resume</li>
                        <li>Upload your revised resume for a new analysis</li>
                        <li>Compare your scores to track improvement</li>
                        <li>Consider tailoring your resume for specific job descriptions</li>
                      </ol>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="resume" className="mt-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium mb-2">Resume Text Analysis</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      We've analyzed your resume text and highlighted issues that may affect ATS compatibility.
                    </p>

                    {results.resumeText && results.resumeIssues ? (
                      <div className="mt-4">
                        <ResumeViewer resumeText={results.resumeText} issues={results.resumeIssues} />
                      </div>
                    ) : (
                      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                        <p className="text-sm text-yellow-700 dark:text-yellow-300">
                          Resume text analysis is not available for this resume. Please upload your resume again to get
                          detailed text analysis.
                        </p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardHeader>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Section Analysis</CardTitle>
              <CardDescription>Detailed breakdown of each resume section</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Contact Information</span>
                    <span className="text-green-600">{results.sections.contactInfo}%</span>
                  </div>
                  <Progress value={results.sections.contactInfo} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Experience</span>
                    <span className="text-green-600">88%</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Skills</span>
                    <span className="text-yellow-600">72%</span>
                  </div>
                  <Progress value={72} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Education</span>
                    <span className="text-green-600">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Header/Footer</span>
                    <span className="text-yellow-600">{results.sections.headerFooter}%</span>
                  </div>
                  <Progress value={results.sections.headerFooter} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Technical Analysis</CardTitle>
              <CardDescription>Technical aspects affecting ATS compatibility</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">File Structure</span>
                    <span className="text-green-600">{results.sections.fileStructure}%</span>
                  </div>
                  <Progress value={results.sections.fileStructure} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Font Compatibility</span>
                    <span className="text-green-600">{results.sections.fonts}%</span>
                  </div>
                  <Progress value={results.sections.fonts} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Text Extraction</span>
                    <span className="text-green-600">92%</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Image Content</span>
                    <span className="text-yellow-600">70%</span>
                  </div>
                  <Progress value={70} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">Parsing Accuracy</span>
                    <span className="text-green-600">88%</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center mt-8">
          <Button size="lg" asChild>
            <Link href="/upload">Analyze Another Resume</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
