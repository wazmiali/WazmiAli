"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error("Results page error:", error)
  }, [error])

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <h2 className="text-2xl font-bold mb-4">Something went wrong</h2>
        <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md">
          We encountered an error while loading the results. Please try again or return to the home page.
        </p>
        <div className="flex gap-4">
          <Button
            onClick={() => {
              // Clear any potentially corrupted data
              try {
                localStorage.removeItem("resumeAnalysis")
              } catch (e) {
                console.error("Error clearing localStorage:", e)
              }
              // Then reset the component
              reset()
            }}
            variant="outline"
          >
            Try Again
          </Button>
          <Button asChild>
            <Link href="/">Return Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
