"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Cloud, UploadCloud } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { FileUploader } from "@/components/file-uploader"
import { PDFParser } from "@/components/pdf-parser"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { generateCsrfToken } from "@/lib/security"

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [isParsing, setIsParsing] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [selectedIndustry, setSelectedIndustry] = useState("Project Management")
  const [jobDescription, setJobDescription] = useState("")
  const [resumeText, setResumeText] = useState<string | null>(null)
  const [resumeIssues, setResumeIssues] = useState<any[]>([])
  const [csrfToken, setCsrfToken] = useState("")
  const { toast } = useToast()
  const router = useRouter()

  // Generate CSRF token on component mount
  useEffect(() => {
    setCsrfToken(generateCsrfToken())
  }, [])

  const handleFileChange = (selectedFile: File | null) => {
    // Reset any previous errors and state
    setError(null)
    setResumeText(null)
    setResumeIssues([])
    setIsParsing(false)

    if (!selectedFile) return

    // Validate file type
    if (selectedFile.type !== "application/pdf") {
      setError("Please upload a PDF file")
      toast({
        title: "Invalid file type",
        description: "Please upload a PDF file",
        variant: "destructive",
      })
      return
    }

    // Validate file size (5MB max)
    if (selectedFile.size > 5 * 1024 * 1024) {
      setError("Maximum file size is 5MB")
      toast({
        title: "File too large",
        description: "Maximum file size is 5MB",
        variant: "destructive",
      })
      return
    }

    setFile(selectedFile)
    setIsParsing(true)
  }

  const handleTextExtracted = (text: string, issues: any[]) => {
    setResumeText(text)
    setResumeIssues(issues)
    setIsParsing(false)
  }

  const handleParseError = (errorMessage: string) => {
    setError(errorMessage)
    setIsParsing(false)
    toast({
      title: "Parsing error",
      description: errorMessage,
      variant: "destructive",
    })
  }

  const handleUpload = async () => {
    if (!file || !resumeText) {
      setError("Please select a file to upload")
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setError(null)

    try {
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 95) {
            clearInterval(interval)
            return prev
          }
          return prev + 5
        })
      }, 300)

      // Simulate API call to analyze resume
      // In a real implementation, we would send the file to the server
      // with proper CSRF protection and content validation
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // Complete the progress
      setUploadProgress(100)

      // Simulate processing time
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Calculate scores based on issues found
      const errorCount = resumeIssues.filter((i) => i.type === "error").length
      const warningCount = resumeIssues.filter((i) => i.type === "warning").length
      const suggestionCount = resumeIssues.filter((i) => i.type === "suggestion").length

      // More issues = lower score
      const baseScore = 85
      const errorPenalty = errorCount * 5
      const warningPenalty = warningCount * 2
      const suggestionPenalty = suggestionCount * 1

      const overallScore = Math.max(0, Math.min(100, baseScore - errorPenalty - warningPenalty - suggestionPenalty))

      // Store analysis results in localStorage
      const analysisResults = {
        overallScore,
        sections: {
          keywords: 72,
          format: 85,
          sections: 90,
          contactInfo: 95,
          headerFooter: 65,
          fonts: 80,
          fileStructure: 75,
        },
        strengths: [
          "Strong experience section with quantifiable achievements",
          "Good use of industry-specific keywords",
          "Clear contact information",
        ],
        weaknesses: [
          "Header formatting may cause parsing issues",
          "Missing some key technical skills keywords",
          "Education section could be more detailed",
        ],
        keywords: {
          present: ["project management", "agile", "team leadership", "budget", "stakeholder"],
          missing: ["scrum", "kanban", "PMP", "risk management", "JIRA"],
          density: 0.68,
          industry: selectedIndustry,
          relevance: 0.75,
          competitiveScore: 65,
        },
        format: {
          issues: resumeIssues
            .filter((i) => i.type === "error" || i.type === "warning")
            .map((i) => ({
              type: i.type === "error" ? "error" : "warning",
              message: i.text,
            })),
          compatibility: 0.85,
          fontAnalysis: {
            primary: "Arial (ATS-friendly)",
            secondary: "Calibri (ATS-friendly)",
            issues: ["Avoid using more than 2 font families"],
          },
          layoutIssues: [
            "Multi-column layout detected in skills section",
            "Tables used for formatting experience section",
          ],
        },
        sectionAnalysis: {
          experience: {
            score: 88,
            strengths: ["Good use of action verbs", "Quantifiable achievements present"],
            weaknesses: ["Some bullet points exceed recommended length"],
          },
          education: {
            score: 85,
            strengths: ["Clear degree information", "Graduation dates included"],
            weaknesses: ["Consider adding relevant coursework"],
          },
          skills: {
            score: 72,
            strengths: ["Good mix of technical and soft skills"],
            weaknesses: ["Skills section could be more structured", "Missing some industry-specific keywords"],
          },
        },
        industryBenchmark: {
          overall: 65,
          keywords: 70,
          format: 68,
          sections: 62,
        },
        fileName: file.name,
        fileSize: file.size,
        uploadDate: new Date().toISOString(),
        jobDescriptionMatch: jobDescription ? 0.72 : null,
        resumeText: resumeText,
        resumeIssues: resumeIssues,
      }

      // Safely store in localStorage with error handling
      try {
        localStorage.setItem("resumeAnalysis", JSON.stringify(analysisResults))
      } catch (storageError) {
        console.error("Error storing results in localStorage:", storageError)
      }

      // Show success message
      toast({
        title: "Analysis complete",
        description: "Your resume has been analyzed successfully",
      })

      // Redirect to results page
      router.push("/results")
    } catch (err) {
      console.error("Upload error:", err)
      setError("There was an error uploading your file. Please try again.")
      toast({
        title: "Upload failed",
        description: "There was an error uploading your file. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Upload Your Resume</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Upload your resume in PDF format to get a comprehensive ATS compatibility analysis
          </p>
        </div>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 p-4 rounded-md">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2">Select Your Industry</label>
            <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Software Development">Software Development</SelectItem>
                <SelectItem value="Data Science">Data Science</SelectItem>
                <SelectItem value="Project Management">Project Management</SelectItem>
                <SelectItem value="Marketing">Marketing</SelectItem>
                <SelectItem value="Finance">Finance</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-1">
              This helps us analyze your resume against industry-specific keywords and standards
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Paste Job Description (Optional)</label>
            <textarea
              className="w-full min-h-[100px] p-2 border rounded-md dark:bg-gray-800 dark:border-gray-700"
              placeholder="Paste the job description to match your resume against specific requirements..."
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              maxLength={5000} // Limit input length for security
            />
            <p className="text-xs text-gray-500 mt-1">
              For more accurate analysis, paste the job description you're applying for
            </p>
          </div>
        </div>

        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="upload">Upload File</TabsTrigger>
            <TabsTrigger value="cloud">Cloud Storage</TabsTrigger>
          </TabsList>
          <TabsContent value="upload" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                {!file && <FileUploader onFileSelect={handleFileChange} accept=".pdf" maxSize={5 * 1024 * 1024} />}
                {file && isParsing && (
                  <PDFParser file={file} onTextExtracted={handleTextExtracted} onError={handleParseError} />
                )}
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="cloud" className="mt-6">
            <Card>
              <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[300px] space-y-4">
                <Cloud className="h-12 w-12 text-gray-400" />
                <h3 className="text-lg font-medium">Connect to Cloud Storage</h3>
                <p className="text-sm text-gray-500 text-center max-w-md">
                  Connect to Google Drive or Dropbox to import your resume directly
                </p>
                <div className="flex gap-4 mt-4">
                  <Button variant="outline" className="gap-2">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M6 12L12 18L18 12"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 2V18"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M20 21H4"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    Google Drive
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M6 12L12 18L18 12"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 2V18"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M20 21H4"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    Dropbox
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {resumeText && (
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Resume Preview</h3>
              <div className="mb-4">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                  We've extracted the text from your resume and identified potential issues:
                </p>
                <div className="flex gap-2 flex-wrap">
                  <div className="flex items-center gap-1 text-xs">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <span>{resumeIssues.filter((i) => i.type === "error").length} Errors</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                    <span>{resumeIssues.filter((i) => i.type === "warning").length} Warnings</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                    <span>{resumeIssues.filter((i) => i.type === "suggestion").length} Suggestions</span>
                  </div>
                </div>
              </div>
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto mb-4">
                <div className="p-4 font-mono text-sm whitespace-pre-wrap">{resumeText}</div>
              </div>
            </CardContent>
          </Card>
        )}

        {file && resumeText && (
          <div className="mt-6 space-y-4">
            {isUploading ? (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{uploadProgress < 100 ? "Analyzing..." : "Processing..."}</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            ) : (
              <Button onClick={handleUpload} className="w-full gap-2">
                <UploadCloud className="h-5 w-5" />
                Analyze Resume
              </Button>
            )}
            {/* Hidden CSRF token for form security */}
            <input type="hidden" name="csrf_token" value={csrfToken} />
          </div>
        )}

        <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
          <h3 className="text-sm font-medium text-blue-800 dark:text-blue-300">Tips for best results:</h3>
          <ul className="mt-2 text-sm text-blue-700 dark:text-blue-400 list-disc list-inside space-y-1">
            <li>Make sure your PDF is not password protected</li>
            <li>Ensure text is selectable and not embedded in images</li>
            <li>Use standard fonts for better compatibility</li>
            <li>Keep your file size under 5MB for faster processing</li>
            <li>Include a job description for targeted analysis</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
