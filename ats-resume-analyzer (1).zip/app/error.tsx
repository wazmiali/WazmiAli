"use client"

import { useEffect } from "react"
import Link from "next/link"
import { AlertCircle } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error)
  }, [error])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4">
      <div className="flex flex-col items-center max-w-md text-center gap-6">
        <div className="p-4 bg-red-100 dark:bg-red-900 rounded-full">
          <AlertCircle className="h-10 w-10 text-red-600 dark:text-red-300" />
        </div>
        <h1 className="text-3xl font-bold">Something went wrong</h1>
        <p className="text-gray-500 dark:text-gray-400">
          We encountered an error while processing your request. Please try again or return to the home page.
        </p>
        <div className="flex gap-4">
          <Button onClick={reset} variant="outline">
            Try Again
          </Button>
          <Button asChild>
            <Link href="/">Return Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
