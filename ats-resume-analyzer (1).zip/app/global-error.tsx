"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error("Global error:", error)
  }, [error])

  return (
    <html>
      <body>
        <div className="flex flex-col items-center justify-center min-h-screen px-4">
          <div className="flex flex-col items-center max-w-md text-center gap-6">
            <h1 className="text-3xl font-bold">Something went wrong</h1>
            <p className="text-gray-500">We encountered an error while processing your request. Please try again.</p>
            <Button
              onClick={() => {
                // Clear any potentially corrupted data
                try {
                  localStorage.removeItem("resumeAnalysis")
                } catch (e) {
                  console.error("Error clearing localStorage:", e)
                }
                // Then reset the application
                reset()
              }}
            >
              Try Again
            </Button>
          </div>
        </div>
      </body>
    </html>
  )
}
