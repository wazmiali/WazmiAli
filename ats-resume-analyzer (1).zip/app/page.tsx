import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  ATS Resume Analyzer
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                  Upload your resume and get a comprehensive ATS compatibility score. Improve your chances of getting
                  past automated screening systems.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/upload">
                  <Button size="lg" className="gap-1.5">
                    Analyze Your Resume <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/about">
                  <Button size="lg" variant="outline">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full aspect-square md:aspect-[4/3] lg:aspect-square overflow-hidden rounded-xl">
                <div className="bg-gradient-to-br from-blue-100 to-indigo-200 dark:from-blue-950 dark:to-indigo-900 w-full h-full flex items-center justify-center">
                  <div className="w-3/4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                    <div className="space-y-4">
                      <div className="h-6 w-3/4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      <div className="space-y-2">
                        <div className="h-4 w-full bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-4 w-full bg-gray-200 dark:bg-gray-700 rounded"></div>
                        <div className="h-4 w-2/3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="h-8 w-24 bg-blue-500 dark:bg-blue-600 rounded"></div>
                        <div className="h-8 w-8 rounded-full bg-green-500 dark:bg-green-600 flex items-center justify-center text-white font-bold">
                          <span>92</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Key Features</h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Our ATS Resume Analyzer provides comprehensive insights to help you optimize your resume
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">ATS Compatibility Score</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Get an overall score from 0-100 on how well your resume will perform with ATS systems
              </p>
            </div>
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">Keyword Analysis</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Identify missing keywords and optimize your content for specific job descriptions
              </p>
            </div>
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">Format Compatibility</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Ensure your resume format, fonts, and structure are ATS-friendly
              </p>
            </div>
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">Section Analysis</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Get feedback on each section of your resume with specific improvement recommendations
              </p>
            </div>
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">Interactive Dashboard</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Visualize your results with charts and graphs for easy understanding
              </p>
            </div>
            <div className="grid gap-1">
              <h3 className="text-xl font-bold">Improvement Tips</h3>
              <p className="text-gray-500 dark:text-gray-400">
                Receive actionable recommendations to improve your resume's performance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">How It Works</h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Our simple process helps you optimize your resume in minutes
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-start gap-6 py-12 lg:grid-cols-3 lg:gap-12">
            <div className="grid gap-1">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-900 mb-4 mx-auto">
                1
              </div>
              <h3 className="text-xl font-bold text-center">Upload Your Resume</h3>
              <p className="text-gray-500 dark:text-gray-400 text-center">
                Drag and drop your PDF resume or upload from cloud storage
              </p>
            </div>
            <div className="grid gap-1">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-900 mb-4 mx-auto">
                2
              </div>
              <h3 className="text-xl font-bold text-center">Automated Analysis</h3>
              <p className="text-gray-500 dark:text-gray-400 text-center">
                Our system analyzes your resume against key ATS criteria
              </p>
            </div>
            <div className="grid gap-1">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-900 mb-4 mx-auto">
                3
              </div>
              <h3 className="text-xl font-bold text-center">Get Detailed Results</h3>
              <p className="text-gray-500 dark:text-gray-400 text-center">
                Review your score and recommendations to improve your resume
              </p>
            </div>
          </div>
          <div className="flex justify-center">
            <Link href="/upload">
              <Button size="lg" className="gap-1.5">
                Try It Now <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-6 bg-gray-100 dark:bg-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <p className="text-gray-500 dark:text-gray-400">© 2025 ATS Resume Analyzer. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
