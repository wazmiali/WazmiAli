import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Rate limiting configuration
const RATE_LIMIT_WINDOW = 60 * 1000 // 1 minute in milliseconds
const MAX_REQUESTS_PER_WINDOW = 100 // Maximum requests per window

// In-memory store for rate limiting (would use Redis in production)
const ipRequestCounts = new Map<string, { count: number; timestamp: number }>()

// Clean up old entries periodically
setInterval(() => {
  const now = Date.now()
  for (const [ip, data] of ipRequestCounts.entries()) {
    if (now - data.timestamp > RATE_LIMIT_WINDOW) {
      ipRequestCounts.delete(ip)
    }
  }
}, RATE_LIMIT_WINDOW)

export function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Get client IP address
  const ip = request.ip || "unknown"

  // Basic rate limiting
  const now = Date.now()
  const requestData = ipRequestCounts.get(ip) || { count: 0, timestamp: now }

  // Reset count if outside window
  if (now - requestData.timestamp > RATE_LIMIT_WINDOW) {
    requestData.count = 0
    requestData.timestamp = now
  }

  // Increment request count
  requestData.count++
  ipRequestCounts.set(ip, requestData)

  // Check if rate limit exceeded
  if (requestData.count > MAX_REQUESTS_PER_WINDOW) {
    return new NextResponse("Too Many Requests", { status: 429 })
  }

  // Add security headers
  const headers = response.headers

  // Content Security Policy
  headers.set(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'",
  )

  // XSS Protection
  headers.set("X-XSS-Protection", "1; mode=block")

  // Prevent MIME type sniffing
  headers.set("X-Content-Type-Options", "nosniff")

  // Referrer Policy
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin")

  // Frame options to prevent clickjacking
  headers.set("X-Frame-Options", "DENY")

  // Strict Transport Security
  headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload")

  // Permissions Policy
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), interest-cohort=()")

  return response
}

// Only run middleware on API routes and upload page
export const config = {
  matcher: ["/api/:path*", "/upload"],
}
